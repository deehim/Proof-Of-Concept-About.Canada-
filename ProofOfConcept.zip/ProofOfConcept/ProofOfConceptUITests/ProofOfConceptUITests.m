//
//  ProofOfConceptUITests.m
//  ProofOfConceptUITests
//
//  Created by SYS-27 on 11/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface ProofOfConceptUITests : XCTestCase

@end

@implementation ProofOfConceptUITests

- (void)setUp {
    [super setUp];
    
    // Put setup code here. This method is called before the invocation of each test method in the class.
    
    // In UI tests it is usually best to stop immediately when a failure occurs.
    self.continueAfterFailure = NO;
    // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
    if (@available(iOS 9.0, *)) {
        [[[XCUIApplication alloc] init] launch];
    } else {
        // Fallback on earlier versions
    }

    
    // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // Use recording to get started writing UI tests.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    

    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    XCUIElementQuery *tablesQuery = app.tables;
    [tablesQuery/*@START_MENU_TOKEN@*/.staticTexts[@"These Saturday night CBC broadcasts originally aired on radio in 1931. In 1952 they debuted on television and continue to unite (and divide) the nation each week."]/*[[".cells[@\"Hockey Night in Canada, These Saturday night CBC broadcasts originally aired on radio in 1931. In 1952 they debuted on television and continue to unite (and divide) the nation each week.\"].staticTexts[@\"These Saturday night CBC broadcasts originally aired on radio in 1931. In 1952 they debuted on television and continue to unite (and divide) the nation each week.\"]",".staticTexts[@\"These Saturday night CBC broadcasts originally aired on radio in 1931. In 1952 they debuted on television and continue to unite (and divide) the nation each week.\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/ tap];
    
    XCUIElement *aboutCanadaButton = app.navigationBars[@"UIView"].buttons[@"About Canada"];
    [aboutCanadaButton tap];
    [tablesQuery.cells[@"Housing, Warmer than you might think."] tap];
    [aboutCanadaButton tap];
    [tablesQuery/*@START_MENU_TOKEN@*/.staticTexts[@"Public Shame"]/*[[".cells[@\"Public Shame, Sadly it's true.\"].staticTexts[@\"Public Shame\"]",".staticTexts[@\"Public Shame\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/ tap];
    [aboutCanadaButton tap];
   
    
}

@end
